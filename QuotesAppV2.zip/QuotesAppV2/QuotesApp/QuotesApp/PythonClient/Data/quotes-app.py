﻿from asyncio.windows_events import NULL
from unittest import result
import requests
import json
import random

quotes_Url = "https://localhost:7086/api/quotes"
register_Url = "https://localhost:7086/api/register"
login_Url = "https://localhost:7086/api/login"

#helper methods
#accept new quote function
def accept_new_quote(access_token, quote_content, quote_author):
    try:
        quotes_Url = "https://localhost:7086/api/quotes"  
        headers = {
            'Authorization': f'Bearer {access_token}',
            'Content-Type': 'application/json'
        }
    
        new_quote = {
            'content': quote_content,
            'author': quote_author
        }
     
        resp = requests.post(quotes_Url, headers=headers, json=new_quote, verify=False)

        if(resp.ok):
           print('Successfully added quote.')
        elif resp.status_code == 401:
           print('You are not authorized to do this, please log in or register first.')
        else:
           print('There was a problem adding a new quote.')
           
        return resp.ok
    
    except Exception as e:
        print(f'Error in accept_new_quote: {e}')
        return False
    
#method to post register user request
def register_user(register_Url, first_name, last_name, username, password, email, phone_number):
    headers = {
        'Content-Type': 'application/json'
    }
    
    register_user_request = {
       "firstName": first_name,
       "lastName": last_name,
       "userName": username,
       "password": password,
       "email": email,
       "phoneNumber": phone_number,
       "roles" : ["QUOTE_MANAGER"] 
    }
    
    resp = requests.post(register_Url, headers=headers, json = register_user_request, verify=False)

    result = {}
    if resp.status_code == 201:
        result['success'] = True
        result['message'] = 'User registered successfully.'  
    else:
        result['success'] = False
        result['message'] = 'There was a problem registering the new user.'
        
    return result

#method to post login existing user request
def login_user(login_Url, username, password):
    headers = {
        'Content-Type': 'application/json'
    }
    
    login_existing_user_request = {
      'username': username,
      'password': password
    }
    
    resp = requests.post(login_Url, headers=headers, json = login_existing_user_request, verify=False)
    
    result = {}
    if resp.status_code == 200:
        result['success'] = True        
        login_result = resp.json()
        result['token'] = login_result['token']
        result['message'] = 'Logged in successfully.'
    else:
        result['success'] = False        
        result['token'] = ''
        result['message'] = 'There was a problem logging in.'
        
    return result
        
    
#methods to handle user requests
#register a new user function
def register_new_user(register_Url):
    print('Please enter the following information:')
    first_name = input('First name? ')
    last_name = input('Last name? ')
    username = input('Username? ')
    password = input('Password? ')
    email = input('Email? ')
    phone_number = input('Phone number? ')
    
    result = register_user(register_Url, first_name, last_name, username, password, email, phone_number)
    print(result['message'] + '\n')


#log in an existing user function
def login_existing_user(login_Url):
    print('Please enter your username and password to log in.')
    username = input('Username? ')
    password = input('Password? ')
    
    result = login_user(login_Url, username, password)
    print(result['message']+ '\n')
    
    return result['token']

#get all quotes function
def get_all_quotes(quotes_Url, access_token):
    
    headers = {
        'Authorization': f'Bearer {access_token}'
    }
    resp = requests.get(quotes_Url, headers=headers, verify=False)
    
    result = ''
    if resp.ok:
                
        quotes_result = resp.json()
        result = random.choice(quotes_result)
        
    elif resp.status_code == 401:
         
         print('You are not authorized to do this, please log in or register first.')
    else:
         
         print('There was a problem getting the quotes.')
         
    return result

# function to load all quotes
def get_all_quotes_from_txt(access_token):
    print('Loading quotes...')
    try:

         quotes_file = open("quotes.txt", "r")
         quotesList = quotes_file.readlines()
         for line in quotesList[:5]:
            quote_info = [c.strip() for c in line.split("--")]
        
            quote_content = quote_info[0]
            quote_author = quote_info[1]
            result = accept_new_quote(access_token, quote_content, quote_author)
            if not result:
                print('Could not load quotes')
                break
         if result:   
            print('Quotes loaded successfully! \n')
    except:
        print('Sorry there was a problem loading the quotes. \n')
        

#function to display a random quote
def display_random_quote(quotes_Url, access_token):
    get_result = get_all_quotes(quotes_Url, access_token)
    if get_result:
        print(f'The randomly selected quote is: \n Quote Content: {get_result["content"]} \n Quote Author: {get_result["author"]}.')
        
    else:
        print('Something went wrong...')
    


#function to add a new quote
def add_new_quote(access_token):
    try:
        quote_content = input('Enter the content of the Quote:')
        quote_author = input('Enter the author of the Quote:')
            
        result = accept_new_quote(access_token, quote_content, quote_author)

        if not result:
           print('The quote was not added successfully. \n')
        else:
           print('The quote was added successfully. \n')
    except:
        print('There was an error somewhere. \n')
        

#main menu
def main():
    done = False
    access_token = ''
    
    while not done:
        print('\n Choose an action: \n')
        print('1. Register a new User. \n')
        print('2. Log in. \n')
        print('3. Load quotes to the Web API. \n')
        print('4. Add a new Quote. \n')
        print('5. Display a randomly selected quote. \n')
        print('6. Quit. \n')
        
        choice = input('Enter the number of your choice: \n')
        
        if choice == '1':
            register_new_user(register_Url)
        elif choice == '2':
            access_token = login_existing_user(login_Url) #assign the token that is returned when the user logs in to the access_token variable
        elif choice == '3':
            get_all_quotes_from_txt(access_token)
        elif choice == '4':
            add_new_quote(access_token)
        elif choice == '5': 
            display_random_quote(quotes_Url, access_token)
        elif choice == '6':
            print('THE END!')
            done = True
        else:
            print('\n Invalid Choice. Please enter a valid option.')
            
if __name__ == "__main__":
 main()









