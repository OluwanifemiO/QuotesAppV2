﻿namespace QuotesApp.Models
{
    public class QuoteViewModel
    {

    }
}
