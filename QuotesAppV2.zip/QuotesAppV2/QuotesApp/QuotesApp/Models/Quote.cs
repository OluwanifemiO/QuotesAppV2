﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;

namespace QuotesApp.Models
{
    public class Quote
    {
        public int QuoteId { get; set; }

        [Required(ErrorMessage = "Please enter the content for the quote.")]
        public string Content { get; set; } = string.Empty;

        public string? Author { get; set; }

        public int? Likes {  get; set; }

        public ICollection<TagAssignment>? TagAssignments { get; set; } 
    }
}
