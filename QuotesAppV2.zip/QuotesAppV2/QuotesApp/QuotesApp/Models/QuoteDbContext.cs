﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using QuotesApp.Configuration;

namespace QuotesApp.Models
{
    public class QuoteDbContext : IdentityDbContext<User>
    {
        public QuoteDbContext(DbContextOptions<QuoteDbContext> options) : base(options)
        {
        }

        public DbSet<Quote> Quotes { get; set;}
        public DbSet<Tag> Tags { get; set;}
        public DbSet<TagAssignment> TagAssignments { get; set;}

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //call the base class
            base.OnModelCreating(modelBuilder);

            modelBuilder.ApplyConfiguration(new RoleConfiguration());

            //set composite key for Tag Assignment
            modelBuilder.Entity<TagAssignment>().HasKey(tg => new { tg.QuotesId, tg.TagsId });

            //set up one to many with quote and tag assignment
            modelBuilder.Entity<TagAssignment>().HasOne(tg => tg.Quote).WithMany(q => q.TagAssignments).HasForeignKey(tg => tg.QuotesId);

            //set up one to many between tag and tag assignment
            modelBuilder.Entity<TagAssignment>().HasOne(tg => tg.Tag).WithMany(t => t.TagAssignments).HasForeignKey(tg => tg.TagsId);

            //seed data into the tables
            modelBuilder.Entity<Quote>().HasData(
                new Quote() {QuoteId = 1, Content = " \"Never put off till tomorrow what you can do the day after tomorrow just as well.\" ", Author = "Mark Twain", Likes = 10},
                new Quote() {QuoteId = 2, Content = " \"Patience is bitter, but its fruit is sweet\" ", Author = "Jean-Jacques Rousseau", Likes = 8},
                new Quote() {QuoteId = 3, Content = " \"My Soldiers, Rage! My Soldiers, Scream! My Soldiers, Fight!\" ", Author = "Erwin Smith", Likes = 100}
                );

            modelBuilder.Entity<Tag>().HasData(
                new Tag() {TagId = 1, TagName = "Funny"},
                new Tag() {TagId = 2, TagName = "Philosophical"},
                new Tag() {TagId = 3, TagName = "Heroic"}
                );

            modelBuilder.Entity<TagAssignment>().HasData(
                new TagAssignment() {QuotesId = 1, TagsId = 1},
                new TagAssignment() {QuotesId = 2, TagsId = 2},
                new TagAssignment() {QuotesId = 3, TagsId = 3}
                );
        }
    }
}
