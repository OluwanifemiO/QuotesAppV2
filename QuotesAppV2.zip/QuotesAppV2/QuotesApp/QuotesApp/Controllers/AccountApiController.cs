﻿using Microsoft.AspNetCore.Mvc;
using QuotesApp.Services;

namespace QuotesApp.Controllers
{
    [ApiController()]
    public class AccountApiController : Controller
    {
        public AccountApiController(IAuthService authService)
        {
            _authService = authService;
        }

        [HttpPost("/api/register")]
        public async Task<IActionResult> RegisterUser(UserRegistrationRequest userRegistrationRequest)
        {


            var result = await _authService.RegisterUser(userRegistrationRequest);

            if (result.Succeeded)
            {
                return StatusCode(StatusCodes.Status201Created);
            }
            else
            {
                foreach (var err in result.Errors)
                {
                    ModelState.TryAddModelError(err.Code, err.Description);
                }

                return BadRequest(ModelState);
            }
        }

        [HttpPost("/api/login")]
        public async Task<IActionResult> LoginUser(LoginRequest loginRequest)
        {
            bool isValidUser = await _authService.LoginUser(loginRequest);

            if (isValidUser)
            {
                return Ok(new { Token = await _authService.CreateToken() });
            }
            else
            {
                return Unauthorized();
            }
        }


        private IAuthService _authService;
    }
}
