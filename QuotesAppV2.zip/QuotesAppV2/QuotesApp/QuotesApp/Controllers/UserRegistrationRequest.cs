﻿namespace QuotesApp.Controllers
{
    public class UserRegistrationRequest:LoginRequest
    {
        public string? FirstName { get; set; }

        public string? LastName { get; set; }

        public string? Email { get; set; }

        public string? PhoneNumber { get; set; }

        public ICollection<string>? Roles { get; set; }
    }
}
