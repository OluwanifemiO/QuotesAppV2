﻿namespace QuotesApp.Controllers
{
    public class TokenInfo
    {
        public string? AccessToken { get; set; }

        public string? RefreshToken { get; set; }
    }
}
