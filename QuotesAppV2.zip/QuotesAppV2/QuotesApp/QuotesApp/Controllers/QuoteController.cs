﻿using Azure;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QuotesApp.Models;

namespace QuotesApp.Controllers
{
    [ApiController()]
    public class QuoteController : Controller
    {
        public QuoteController(QuoteDbContext quoteDbContext)
        {
            _quoteDbContext = quoteDbContext;
        }

        //Get All Quotes Action
        [HttpGet("/api/quotes")]
        [Authorize()]
        public async Task<IActionResult> GetAllQuotes()
        {
            var quotes = await _quoteDbContext.Quotes
                .Include(q => q.TagAssignments)
                .ThenInclude(ta => ta.Tag)
                .Select(q => new QuoteInfo()
                {
                    QuoteId = q.QuoteId,
                    Content = q.Content,
                    Author = q.Author,
                    Likes = q.Likes,
                    TagNames = q.TagAssignments.Select(ta => ta.Tag.TagName).ToList() //changes here
                })
                .ToListAsync();

            return Ok(quotes);
        }

        //Get Quotes by Id Action
        [HttpGet("/api/quotes/{id}")]
        [Authorize()]
        public async Task<IActionResult> GetQuoteById(int id)
        {
            QuoteInfo? quote = await _quoteDbContext.Quotes
                .Include(q => q.TagAssignments)
                .ThenInclude(ta => ta.Tag)
                .Select(q => new QuoteInfo()
                {
                    QuoteId = q.QuoteId,
                    Content = q.Content,
                    Author = q.Author,
                    Likes = q.Likes,
                    TagNames = q.TagAssignments.Select(ta => ta.Tag.TagName).ToList() //changes here
                })
                .Where(q => q.QuoteId == id)
                .FirstOrDefaultAsync();

            if (quote == null)
            {
                return NotFound();
            }

            return Ok(quote);
        }


        //Get Quote By Tag
        [HttpGet("/api/quotes/tag/{tagName}")]
        [Authorize()]
        public async Task<IActionResult> GetQuotesByTag(string tagName)
        {
            var quotes = await _quoteDbContext.Quotes
                             .Where(q => q.TagAssignments.Any(ta => ta.Tag.TagName == tagName))
                             .Include(q => q.TagAssignments)
                             .ThenInclude(ta => ta.Tag)
                             .Select(q => new QuoteInfo()
                             {
                                 QuoteId = q.QuoteId,
                                 Content = q.Content,
                                 Author = q.Author,
                                 Likes = q.Likes,
                                 TagNames = q.TagAssignments.Select(ta => ta.Tag.TagName).ToList()
                             })
                                .ToListAsync();

            if (quotes == null || quotes.Count == 0)
            {
                return NotFound();
            }

            return Ok(quotes);
        }



        //Get all Tags Action
        [HttpGet("/api/tags")]
        [Authorize()]
        public async Task<IActionResult> GetAllTags()
        {
            var tags = await _quoteDbContext.Tags
                  .OrderBy(t => t.TagId)
                  .Select(t => new { TagId = t.TagId, TagName = t.TagName })
                  .ToListAsync();

            if (tags == null)
            {
                return NotFound();
            }

            return Ok(tags);

        }


        //update tag
        [HttpPost("/api/tags/update/{id}")]
        [Authorize()]
        public async Task<IActionResult> UpdateTag(int id, [FromBody] Tag updatedTag)
        {
            try
            {

                var existingTag = await _quoteDbContext.Tags.FindAsync(id);

                if (existingTag == null)
                {
                    return NotFound("No Tag by that name.");
                }

                existingTag.TagName = updatedTag.TagName;
                await _quoteDbContext.SaveChangesAsync();
            }
            catch (Exception)
            {

                return BadRequest("There was an error somewhere.");
            }

            return Ok("Tag updated successfully");

        }

        //Add a Quote
        [HttpPost("/api/quotes")]
        [Authorize()]
        public async Task<IActionResult> AddNewQuote([FromBody] NewQuoteRequest newQuoteRequest)
        {
            //create a new quote entity and save it to the database
            Quote newQuote = new Quote()
            {
                Content = newQuoteRequest.Content,
                Author = newQuoteRequest.Author,
                Likes = newQuoteRequest.Likes
                //TagAssignment = newQuoteRequest.
            };
            _quoteDbContext.Quotes.Add(newQuote);
            await _quoteDbContext.SaveChangesAsync();

            //send it to the quoteInfo as well
            QuoteInfo quoteInfo = new QuoteInfo()
            {
                QuoteId = newQuote.QuoteId,
                Content = newQuote.Content,
                Author = newQuote.Author,
                Likes = newQuote.Likes
            };

            return Ok(quoteInfo);
        }


        //Edit quote
        [HttpPost("/api/quotes/edit/{id}")]
        [Authorize()]
        public async Task<IActionResult> EditQuote(int id, [FromBody] QuoteInfo updatedQuote)
        {
            try
            {
                //find the existing quote using the id
                var existingQuote = await _quoteDbContext.Quotes.FindAsync(id);

                //if it doesn't exist, return not found
                if (existingQuote == null)
                {
                    return NotFound();
                }

                //update the properties of the existing quote
                existingQuote.Content = updatedQuote.Content;
                existingQuote.Author = updatedQuote.Author;

                //save changes to the database
                await _quoteDbContext.SaveChangesAsync();

                //send the updated quote information in the response
                var updatedQuoteInfo = new QuoteInfo()
                {
                    QuoteId = existingQuote.QuoteId,
                    Content = existingQuote.Content,
                    Author = existingQuote.Author
                };

                //return the updated quote information
                return Ok(updatedQuoteInfo);
            }
            catch (Exception)
            {
                //if an exception occurs, return a bad request response
                return BadRequest();
            }
        }



        //Delete quote
        [HttpDelete("/api/quotes/delete/{id}")]
        public async Task<IActionResult> DeleteQuote(int id)
        {
            //find the exisiting quote using the id
            var existingQuote = await _quoteDbContext.Quotes.FindAsync(id);

            //if it doesn't exist, say not found
            if (existingQuote == null)
            {
                return NotFound();
            }
            else
            {
                _quoteDbContext.Remove(existingQuote);
                await _quoteDbContext.SaveChangesAsync();

            }

            return Ok();
        }



        //Like a quote
        [HttpPost("/api/quotes/likes/{id}")]
        [Authorize()]
        public async Task<IActionResult> LikeQuote(int id)
        {
            //find the exisiting quote using the id
            var existingQuote = await _quoteDbContext.Quotes.FindAsync(id);

            //if it doesn't exist, say not found
            if (existingQuote == null)
            {
                return NotFound();
            }
            else
            {
                //increment the likes of the existing quote

                existingQuote.Likes++;

                await _quoteDbContext.SaveChangesAsync();

                return Ok(new { Likes = existingQuote.Likes });
            }
        }


        //Get most liked quotes, default 10
        [HttpGet("/api/quotes/most-liked")]
        [Authorize()]
        public async Task<IActionResult> GetMostLikedQuotes([FromQuery] int count = 10)
        {
            var mostLikedQuotes = await _quoteDbContext.Quotes
                 .OrderByDescending(q => q.Likes)
                 .Take(count)
                 .Include(q => q.TagAssignments)
                 .ThenInclude(ta => ta.Tag)
                 .Select(q => new QuoteInfo()
                 {
                     QuoteId = q.QuoteId,
                     Content = q.Content,
                     Author = q.Author,
                     Likes = q.Likes,
                     TagNames = q.TagAssignments.Select(ta => ta.Tag.TagName).ToList()
                 })
                 .ToListAsync();

            return Ok(mostLikedQuotes);
        }


        //tag a quote
        [HttpPost("/api/quotes/{id}/tagQuote")]
        [Authorize()]
        public async Task<IActionResult> AddTagToQuote(int id, [FromBody] Tag tagName)
        {
            try
            {
                if (string.IsNullOrEmpty(tagName.TagName))
                {
                    return BadRequest("Please enter a tag.");
                }

                tagName.TagName = tagName.TagName.ToLower();

                var existingQuote = await _quoteDbContext.Quotes.Include(q => q.TagAssignments)
                    .ThenInclude(qt => qt.Tag)
                    .FirstOrDefaultAsync(q => q.QuoteId == id);

                var existingTag = await _quoteDbContext.Tags
                    .FirstOrDefaultAsync(t => t.TagName.ToLower() == tagName.TagName);

                if (existingTag != null)
                {
                    var existingTagAssignment = new TagAssignment { QuotesId = id, Tag = existingTag };
                    existingQuote.TagAssignments.Add(existingTagAssignment);
                    await _quoteDbContext.SaveChangesAsync();

                    return Ok(new { TagId = existingTag.TagId });
                }

                var tagAssignment = new TagAssignment { QuotesId = id, Tag = tagName };
                existingQuote.TagAssignments.Add(tagAssignment);
                await _quoteDbContext.Tags.AddAsync(tagName);
                await _quoteDbContext.SaveChangesAsync();

                return Ok(new { TagId = tagName.TagId });
            }
            catch (Exception)
            {
                return StatusCode(500);
            }
        }


        [HttpGet("/api/tags/suggest")]
        public IActionResult GetTagSuggestions(string term)
        {
            // Query your database or other data source to get tag suggestions based on 'term'
            var tagSuggestions = _quoteDbContext.Tags
                .Where(t => t.TagName.StartsWith(term))
                .Select(t => t.TagName)
                .ToList();

            return Ok(tagSuggestions);
        }


        private QuoteDbContext _quoteDbContext;

    }
}
