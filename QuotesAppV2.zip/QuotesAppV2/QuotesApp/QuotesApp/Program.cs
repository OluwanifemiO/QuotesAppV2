using Microsoft.EntityFrameworkCore;
using QuotesApp.Extensions;
using QuotesApp.Services;
using QuotesApp.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRouting(options =>
{
    options.LowercaseUrls = true;
    options.AppendTrailingSlash = true;
});

// Add services to the container.
builder.Services.AddControllersWithViews().AddXmlSerializerFormatters();

// Add CORS support, first by defining a CORS policy by name:
builder.Services.AddCors(options => {
    options.AddPolicy("AllowQuoteClients", policy => {
        policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader();
    });
});

var connStr = builder.Configuration.GetConnectionString("QuoteDB");
builder.Services.AddDbContext<QuoteDbContext>(options => options.UseSqlServer(connStr));

builder.Services.AddAuthentication();

// call our 2 ext'n methods:
builder.Services.ConfigureCors();
builder.Services.ConfigureIdentity();
builder.Services.ConfigureJwtAuthentication(builder.Configuration);

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// we use the CORS policy defined above by name:
app.UseCors("AllowQuoteClients");

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
