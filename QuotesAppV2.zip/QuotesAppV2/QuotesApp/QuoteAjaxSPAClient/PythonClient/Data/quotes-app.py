﻿import requests
import json
import random

quotes_Url = "https://localhost:7086/api/quotes"

#accept new quote function
def accept_new_quote(quote_content, quote_author):
    try:
        quotes_Url = "https://localhost:7086/api/quotes"  # Replace with your actual API URL
        headers = {'Content-Type': 'application/json'}
    
        new_quote = {
            'content': quote_content,
            'author': quote_author
        }
     
        resp = requests.post(quotes_Url, headers=headers, json=new_quote, verify=False)

        # Check for a successful response (status code 201 and 'Location' in headers)
        return resp.ok
    
    except Exception as e:
        print(f'Error in accept_new_quote: {e}')
        return False
        
    
#get all quotes function
def get_all_quotes(quotes_Url):
    resp = requests.get(quotes_Url, verify=False)
    quotes = resp.json()
    random_quote = random.choice(quotes)
    return random_quote

# function to load all quotes
def get_all_quotes_from_txt():
    print('Loading quotes...')
    try:

         quotes_file = open("quotes.txt", "r")
         quotesList = quotes_file.readlines()
         for line in quotesList[:5]:
            quote_info = [c.strip() for c in line.split("--")]
        
            quote_content = quote_info[0]
            quote_author = quote_info[1]
            quote_added_successfully = accept_new_quote(quote_content, quote_author)
                             
         print('Quotes loaded successfully! \n')
    except:
        print('Sorry there was a problem loading the quotes \n')
        

#function to display a random quote
def display_random_quote(quotes_Url):
    random_quote = get_all_quotes(quotes_Url)
    #random_quote = random.choice(all_quotes)
    print(f'The randomly selected quote is: \n Quote Content: {random_quote["content"]} \n Quote Author: {random_quote["author"]}')


#function to add a new quote
def add_new_quote():
    try:
        quote_content = input('Enter the content of the Quote:')
        quote_author = input('Enter the author of the Quote:')
            
        quote_added_successfully = accept_new_quote(quote_content, quote_author)

        if quote_added_successfully:
           print('The quote was added successfully. \n')
        else:
           print('Sorry, there was a problem adding the new quote. \n')
    except:
        print('There was an error somewhere. \n')
        

#main menu
def main():
    done = False
    while not done:
        print('\n Choose an action: \n')
        print('1. Load quotes to the Web API. \n')
        print('2. Add a new Quote. \n')
        print('3. Display a randomly selected quote. \n')
        print('4. Quit. \n')
        
        choice = input('Enter the number of your choice: \n')
        
        if choice == '1':
            get_all_quotes_from_txt()
        elif choice == '2':
            add_new_quote()
        elif choice == '3': 
            display_random_quote(quotes_Url)
        elif choice == '4':
            print('THE END!')
            done = True
        else:
            print('\n Invalid Choice. Please enter a valid option.')
            
if __name__ == "__main__":
 main()









